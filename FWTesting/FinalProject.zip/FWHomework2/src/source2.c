#include "source2.h"

char mygetchar(void)
{
	char a;
	a = 'a';
	return a;
}
