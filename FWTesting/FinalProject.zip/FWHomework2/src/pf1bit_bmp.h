#ifndef PF1BIT_BMP_H
#define PF1BIT_BMP_H
void MakeBitmap(int * imgArray, char * filename);

#endif