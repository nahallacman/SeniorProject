#ifndef SOURCE2_H
#define SOURCE2_H

char mygetchar(void);

#endif