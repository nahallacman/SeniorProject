//#include<stdio.h>
#ifndef COMPAREFILES_H
#define COMPAREFILES_H
 
int comparefiles(char * fname1, char * fname2);

#endif