//here is a testing define, comment this out for testing on the PC, leave it for the PIC32 code
// #ifndef __Microcontroller
// #define __Microcontroller
// #endif